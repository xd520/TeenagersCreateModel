//
//  BankCardViewController.h
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-10.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface BankCardViewController : UIViewController <NetworkModuleDelegate,MBProgressHUDDelegate,UITableViewDataSource,UITableViewDelegate>

@end
