//
//  FirstViewController.h
//  TeenagersCreateModel
//
//  Created by mac on 14-10-11.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"



@class AppDelegate;
@interface FirstViewController : UIViewController <UIScrollViewDelegate,MBProgressHUDDelegate,NetworkModuleDelegate>

@property(nonatomic,strong) AppDelegate *appDelegate;


@end
