//
//  FirstViewController.m
//  TeenagersCreateModel
//
//  Created by mac on 14-10-11.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import "FirstViewController.h"
#import "ColorUtil.h"
#import"SecondViewController.h"
#import "AppDelegate.h"
#import "ProjectIntroductionViewController.h"
#import "FirstPioneerViewController.h"
#import "IndividualCenterViewController.h"
#import "MyAccountViewController.h"
#import "LeveyTabBarController.h"
#import "AsyncImageView.h"
#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "UIImageView+WebCache.h"
#import "SDImageCache.h"
#import "SGFocusImageFrame.h"
#import "SGFocusImageItem.h"


@interface FirstViewController ()
{
    NSString *start;
    NSString *limit;
    UIScrollView *scrollView;
    NSMutableArray *slideImages;
    UIPageControl *pageControl;
    NSMutableArray *array;
}

@end

@implementation FirstViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    self.title = @"青创板";
        
    }
    return self;
}

-(void)loadView {
    [super loadView];
    UIView *baseView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
    baseView.backgroundColor = [ColorUtil colorWithHexString:@"eeeeee"];
    self.view = baseView;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
//过滤缓存
//    [[SDWebImageManager sharedManager] setCacheKeyFilter:^(NSURL *url)
//     {
//         url = [[NSURL alloc] initWithScheme:url.scheme host:url.host path:url.path];
//         return [url absoluteString];
//     }];

    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    
    start = @"1";
    limit = @"10";
    // 定时器 循环
    [NSTimer scheduledTimerWithTimeInterval:4 target:self selector:@selector(runTimePage) userInfo:nil repeats:YES];
    //获取AppDelegate
    self.appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
/*
    // 导航栏右边按钮的设置
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(ScreenWidth - 10 - 21, 12, 21, 21);
    [leftBtn setImage:[UIImage imageNamed:@"head_icon_back"] forState:UIControlStateNormal];
    //leftBtn.backgroundColor = [UIColor redColor];
    [leftBtn addTarget:self action:@selector(push:) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationController.navigationBar addSubview:leftBtn];
//    self.navigationItem.hidesBackButton = YES;
 */
    
    if ([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0) {
        self.edgesForExtendedLayout=UIRectEdgeNone;
    }
    
   
    //用户注册
    UIButton *userRegesterBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    userRegesterBtn.frame = CGRectMake(20, 223, 130, 40);
    userRegesterBtn.backgroundColor = [UIColor blueColor];
    [userRegesterBtn setTintColor:[UIColor blueColor]];
    [userRegesterBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [userRegesterBtn setTitle:@"用户注册" forState:UIControlStateNormal];
    userRegesterBtn.tag = 1;
    [userRegesterBtn addTarget:self action:@selector(pushViewMethods:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:userRegesterBtn];
    
    
    //立即登录
    UIButton *userLoginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    userLoginBtn.frame = CGRectMake(170, 223, 130, 40);
    userLoginBtn.backgroundColor = [UIColor blueColor];
    [userLoginBtn setTintColor:[UIColor blueColor]];
    [userLoginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [userLoginBtn setTitle:@"立即登录" forState:UIControlStateNormal];
    [userLoginBtn addTarget:self action:@selector(pushViewMethods:) forControlEvents:UIControlEventTouchUpInside];
    userLoginBtn.tag = 2;
    [self.view addSubview:userLoginBtn];
    

    //添加指示器及遮罩
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.labelText = @"加载中...";
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_LOW, 0), ^{
        [self requestUpdateLinkMan];
        [self requestUpdateList];
        dispatch_async(dispatch_get_main_queue(), ^{
           
        });
    });
    
 
}



-(void)pushViewMethods:(UIButton *)btn {
    if (btn.tag == 2) {
       
        LoginViewController *cv = [[LoginViewController alloc] init];
        cv.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:cv animated:YES];
    } else if (btn.tag == 1){
        RegisterViewController *cv = [[RegisterViewController alloc] init];
        cv.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:cv animated:YES];
    
    }
}


- (void)requestUpdateLinkMan
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"请求修改联系人");
    NSMutableDictionary *paraDic = [[NSMutableDictionary alloc] init];

    [[NetworkModule sharedNetworkModule] postBusinessReqWithParamters:paraDic tag:kBusinessTagGetBanner owner:self];
    
}

- (void)requestUpdateList
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"请求修改联系人");
    NSMutableDictionary *paraDic = [[NSMutableDictionary alloc] init];
    [paraDic setObject:start forKey:@"rowIndex"];
    [paraDic setObject:limit forKey:@"rowCount"];
    [paraDic setObject:@"2" forKey:@"type"];
    [[NetworkModule sharedNetworkModule] postBusinessReqWithParamters:paraDic tag:kBusinessTagGetWYTZ owner:self];
    
}


    



#pragma mark - Recived Methods
//处理修改联系人
- (void)recivedUpdateLinkMan:(NSMutableArray *)dataArray
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"修改联系人");
    
    if ([slideImages count] > 0) {
        [slideImages removeAllObjects];
        for (NSDictionary *object in dataArray) {
            [slideImages addObject:object];
        }
    } else {
        slideImages = dataArray;
    }
    
     [MBProgressHUD hideHUDForView:self.view animated:YES];
 //保存数组的个数
    
    NSNumber *num = [NSNumber numberWithInteger:slideImages.count];
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:num forKey:@"arrCount"];
    [userDefault synchronize];
    
    
    CGRect bound=CGRectMake(0, 0, ScreenWidth, 200);
    
    scrollView = [[UIScrollView alloc] initWithFrame:bound];
    scrollView.bounces = YES;
    scrollView.pagingEnabled = YES;
    scrollView.delegate = self;
    scrollView.userInteractionEnabled = YES;
    scrollView.showsHorizontalScrollIndicator = YES;
    [self.view addSubview:scrollView];
    
    
    // 初始化 pagecontrol
    pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(0,180,ScreenWidth,10)]; // 初始化mypagecontrol
    [pageControl setCurrentPageIndicatorTintColor:[UIColor redColor]];
    [pageControl setPageIndicatorTintColor:[UIColor blackColor]];
    pageControl.numberOfPages = [slideImages count];
    pageControl.currentPage = 0;
    [pageControl addTarget:self action:@selector(turnPage) forControlEvents:UIControlEventValueChanged]; // 触摸mypagecontrol触发change这个方法事件
    [self.view addSubview:pageControl];
    array = [[NSMutableArray alloc] init];
    for (int i = 0; i < slideImages.count; i++) {
       UIImageView *imageView1 = [[UIImageView alloc] initWithFrame:CGRectMake((ScreenWidth * i) + ScreenWidth, 0, ScreenWidth, 200)];
        [imageView1 setTag:i + 10000];
        [imageView1 setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVERURL,[[slideImages objectAtIndex:i] objectForKey:@"value"]]]
                       placeholderImage:[UIImage imageNamed:@"placeholder.png"]
        success:^(UIImage *image) {
            
            [[SDImageCache sharedImageCache] storeImage:image forKey:[NSString stringWithFormat:@"myCacheKey%d",i]];
            
            
//一。图片存储到沙盒中
            /*
            NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
            NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"pic_%d.png", i]];   // 保存文件的名称
            [UIImagePNGRepresentation(image)writeToFile: filePath    atomically:YES];
            
            
            
//二。在plist中保存路径
            NSMutableDictionary *info = [[NSMutableDictionary alloc]init];
            [info setObject:filePath forKey:@"img"];
            //[info setObject:[NSString stringWithFormat:@"%ld",slideImages.count] forKey:@"count"];
           */
            
                                }
         
        failure:^(NSError *error) {
            
            UIImageView *icon = (UIImageView *)[(UIImageView *)self.view viewWithTag:i + 10000];
            icon.image = [UIImage imageNamed:@"xd1"];
                                }];
        
        [scrollView addSubview:imageView1];
      
        
    }
    
    
    // 取数组最后一张图片 放在第0页
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 200)];
     UIImageView *icon = (UIImageView *)[(UIImageView *)self.view viewWithTag:[slideImages count] - 1 + 10000];
    imgView.image = icon.image;
    [scrollView addSubview:imgView];
    
    // 取数组第一张图片 放在最后1页
    
   imgView = [[UIImageView alloc] initWithFrame:CGRectMake((320 * ([slideImages count] + 1)) , 0, 320, 200)];
    
    icon = (UIImageView *)[(UIImageView *)self.view viewWithTag:0 + 10000];
    imgView.image = icon.image;
    
    // 添加第1页在最后 循环
    [scrollView addSubview:imgView];
    
    [scrollView setContentSize:CGSizeMake(320 * ([slideImages count] + 2), 200)]; //  +上第1页和第4页  原理：4-[1-2-3-4]-1
    [scrollView setContentOffset:CGPointMake(0, 0)];
    [scrollView scrollRectToVisible:CGRectMake(320,0,320,200) animated:NO]; // 默认从序号1位置放第1页 ，序号0位置位置放第4页
    
   
    
}
#pragma mark - NetworkModuleDelegate Methods
-(void)beginPost:(kBusinessTag)tag{
    
}
-(void)endPost:(NSString *)result business:(kBusinessTag)tag{
    NSLog(@"%s %d 收到数据:%@", __FUNCTION__, __LINE__, result);
    NSMutableDictionary *jsonDic = [result JSONValue];
    NSMutableArray *dataArray = [jsonDic objectForKey:@"object"];
	if (tag==kBusinessTagGetBanner ) {
       
        if ([[jsonDic objectForKey:@"success"] boolValue] == NO) {
            //数据异常处理
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            [self.view makeToast:@"下载图片失败"];
            //            subing = NO;
        } else {
            [self recivedUpdateLinkMan:dataArray];
        }
    }
    
    [[NetworkModule sharedNetworkModule] cancel:tag];
}
-(void)errorPost:(NSError *)err business:(kBusinessTag)tag{
    NSLog(@"%s Error:%@", __FUNCTION__, @"连接数据服务器超时");
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法连接" message:@"您所在地的网络信号微弱，无法连接到服务" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    if (tag==kBusinessTagGetBanner) {
     [MBProgressHUD hideHUDForView:self.view animated:YES];
    }
    [[NetworkModule sharedNetworkModule] cancel:tag];
    
      if (slideImages.count == 0) {
        
          slideImages = [[NSMutableArray alloc] init];
          NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
          NSNumber *arr = [userDefault objectForKey:@"arrCount"];
          NSInteger count = [arr integerValue];
          if (count > 0) {
          
          for (int i = 0; i < count; i++) {
              UIImage *icon = [[SDImageCache sharedImageCache] imageFromKey:[NSString stringWithFormat:@"myCacheKey%d",i]];
              [slideImages addObject:icon];
          }
          
          
          
          CGRect bound=CGRectMake(0, 0, ScreenWidth, 200);
          
          scrollView = [[UIScrollView alloc] initWithFrame:bound];
          scrollView.bounces = YES;
          scrollView.pagingEnabled = YES;
          scrollView.delegate = self;
          scrollView.userInteractionEnabled = YES;
          scrollView.showsHorizontalScrollIndicator = YES;
          [self.view addSubview:scrollView];
          
          // 初始化 pagecontrol
          pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(0,180,ScreenWidth,10)]; // 初始化mypagecontrol
          [pageControl setCurrentPageIndicatorTintColor:[UIColor redColor]];
          [pageControl setPageIndicatorTintColor:[UIColor blackColor]];
          pageControl.numberOfPages = slideImages.count;
          pageControl.currentPage = 0;
          [pageControl addTarget:self action:@selector(turnPage) forControlEvents:UIControlEventValueChanged]; // 触摸mypagecontrol触发change这个方法事件
          [self.view addSubview:pageControl];
          
         
          for (int i = 0; i < slideImages.count; i++) {
              UIImageView *imageView1 = [[UIImageView alloc] initWithFrame:CGRectMake((ScreenWidth * i) + ScreenWidth, 0, ScreenWidth, 200)];
              imageView1.image = [slideImages objectAtIndex:i];
                [scrollView addSubview:imageView1];
              
          }
          
          
          // 取数组最后一张图片 放在第0页
          
          UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 200)];
        // UIImageView *icon = [slideImages objectAtIndex:slideImages.count -1];
          imgView.image = [slideImages objectAtIndex:slideImages.count -1];
          [scrollView addSubview:imgView];
          
          // 取数组第一张图片 放在最后1页
          
          imgView = [[UIImageView alloc] initWithFrame:CGRectMake((320 * ([slideImages count] + 1)) , 0, 320, 200)];
          
         //icon = [slideImages objectAtIndex:0];
          imgView.image = [slideImages objectAtIndex:0];
          
          // 添加第1页在最后 循环
          [scrollView addSubview:imgView];
          
          [scrollView setContentSize:CGSizeMake(320 * ([slideImages count] + 2), 200)]; //  +上第1页和第4页  原理：4-[1-2-3-4]-1
          [scrollView setContentOffset:CGPointMake(0, 0)];
          [scrollView scrollRectToVisible:CGRectMake(320,0,320,200) animated:NO]; // 默认从序号1位置放第1页 ，序号0位置位置放第4页
          
          }
    }
}

#pragma mark -
- (void)foucusImageFrame:(SGFocusImageFrame *)imageFrame didSelectItem:(SGFocusImageItem *)item
{
    NSLog(@"%@ tapped", item.title);
}


// scrollview 委托函数
- (void)scrollViewDidScroll:(UIScrollView *)sender
{
    CGFloat pagewidth = scrollView.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pagewidth/([slideImages count]+2))/pagewidth)+1;
    page --;  // 默认从第二页开始
    pageControl.currentPage = page;
}
// scrollview 委托函数
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollV
{
    CGFloat pagewidth = scrollView.frame.size.width;
    int currentPage = floor((scrollView.contentOffset.x - pagewidth/ ([slideImages count]+2)) / pagewidth) + 1;
    //    int currentPage_ = (int)self.scrollView.contentOffset.x/320; // 和上面两行效果一样
    //    NSLog(@"currentPage_==%d",currentPage_);
    if (currentPage==0)
    {
        [scrollView scrollRectToVisible:CGRectMake(320 * [slideImages count],0,320,200) animated:NO]; // 序号0 最后1页
    }
    else if (currentPage==([slideImages count]+1))
    {
        [scrollView scrollRectToVisible:CGRectMake(320,0,320,200) animated:NO]; // 最后+1,循环第1页
    }
}
// pagecontrol 选择器的方法
- (void)turnPage
{
    int page = (int)pageControl.currentPage; // 获取当前的page
    [scrollView scrollRectToVisible:CGRectMake(320*(page+1),0,320,200) animated:NO]; // 触摸pagecontroller那个点点 往后翻一页 +1
}
// 定时器 绑定的方法
- (void)runTimePage
{
    int page = (int)pageControl.currentPage; // 获取当前的page
    page++;
    page = page > (slideImages.count - 1) ? 0 : page ;
    pageControl.currentPage = page;
    [self turnPage];
}

#pragma mark - AsyncImageView Delegate Methods
- (void)succ:(AsyncImageView *)sender
{
    NSLog(@"****");
  //数据图片保存
   NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL success = [fileManager createFileAtPath:[self dataFilePath] contents:nil attributes:nil];
    if (success) {
        NSLog(@"create success");
        
        array = [[NSMutableArray alloc] init];
        [array addObject:sender];
        [array writeToFile:[self dataFilePath] atomically:YES];
    }
    NSString *filePath = [self dataFilePath];
     if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
         [array addObject:sender];
         [array writeToFile:filePath atomically:YES];
     }
    
}

#pragma mark - 持久化保存数据方法

-(NSString *)dataFilePath {
    
    NSString *path = NSHomeDirectory();
     NSString *filePath = [path stringByAppendingPathComponent:@"data.plist"];
    return filePath;

}


- (void)fal:(NSError *)sender
{
    NSURL *url = [sender.userInfo objectForKey:@"NSLocalizedDescription"];
    int picCount = (int)[slideImages count];
    for (int i = 0; i < picCount; i ++) {
        if ([[slideImages objectAtIndex:i] isEqualToString:[url absoluteString]]) {
            AsyncImageView *imageView1 = (AsyncImageView *)[(AsyncImageView *)self.view viewWithTag:i + 10000];
            [imageView1 setImage:[UIImage imageNamed:@"xd1"]];
            
        }
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   [[NSURLCache sharedURLCache] removeAllCachedResponses];
}

-(void)dealloc {

    [scrollView removeFromSuperview];
    [pageControl removeFromSuperview];
    scrollView = nil;
    pageControl = nil;
    [slideImages removeAllObjects];
    slideImages = nil;
    
    start = nil;
    limit = nil;
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
}

@end
