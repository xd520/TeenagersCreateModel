//
//  AppDelegate.h
//  TeenagersCreateModel
//
//  Created by mac on 14-10-11.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ColorUtil.h"
#import "Base64.h"
#import "MBProgressHUD.h"
#import "NetworkModule.h"
#import "OpenUDID.h"
#import "Toast+UIView.h"
#import "SBJson.h"
#import "SRRefreshView.h"
#import "AsyncImageView.h"
#import "SHLUILabel.h"
#import "ILBarButtonItem.h"
#import "UIView+MGBadgeView.h"
#import "EAIntroView.h"
#import "ASIHTTPRequest.h"

//请求数据头 http://192.168.1.57:8011/appservice
//广州请求数据地址：http://183.62.241.11:8080/
//#define SERVERURL @"http://192.168.1.57:8011/appservice/wsCommon/service"
#define SERVERURL @"http://183.62.241.11:8080"

//资讯请求头
#define SERVERDETAIL1 @"http://183.62.241.11:8080/app/index/infoWeb/mobiledetail/"
#define SERVERDETAIL2 @"http://183.62.241.11:8080/app/index/infoWeb/mobiledetail/"
#define SERVERDETAIL3 @"http://183.62.241.11:8080/app/index/infoWeb/mobiledetail/"



@class LeveyTabBarController;
@interface AppDelegate : UIResponder <UIApplicationDelegate,UINavigationControllerDelegate,EAIntroDelegate>


{
    LeveyTabBarController *leveyTabBarController;
    // ASIDownloadCache *myCache;
}

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong)  LeveyTabBarController *leveyTabBarController;
@property(nonatomic,strong)NSMutableArray *array;
@property(nonatomic,strong)NSString *numStr;


@end
