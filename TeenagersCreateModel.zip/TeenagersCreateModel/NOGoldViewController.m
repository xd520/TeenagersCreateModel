//
//  NOGoldViewController.m
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-26.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import "NOGoldViewController.h"
#import "AppDelegate.h"
#import "KxMenu.h"

@interface NOGoldViewController ()
{
    UIButton *bankNumTF;
    UILabel *SelectLable;
    NSArray *array3;
    NSString *bankName;
    UITextField *password;
    MBProgressHUD *HUD;
   
}
@end

@implementation NOGoldViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)loadView {
    [super loadView];
    self.navigationController.navigationBarHidden = YES;
    UIView *baseView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
    baseView.backgroundColor = [ColorUtil colorWithHexString:@"f5f4f2"];
    //baseView.backgroundColor = [UIColor grayColor];
    self.view = baseView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UINavigationBar *navibar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, ScreenWidth, 44)];
    navibar.userInteractionEnabled = YES;
    //navibar.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"navbar.png"]];
    [navibar setBackgroundImage:[UIImage imageNamed:@"background.jpg"]  forBarMetrics:UIBarMetricsDefault];
    
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 21, 21);
    [leftBtn setImage:[UIImage imageNamed:@"head_icon_back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(push) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    UINavigationItem *navibarItem = [[UINavigationItem alloc]init];
    navibarItem.title = @"出金";
    navibarItem.leftBarButtonItem= leftItem;
    // self.navigationItem.rightBarButtonItem = leftItem;
    [navibar pushNavigationItem:navibarItem animated:YES];
    [self.view addSubview:navibar];
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 70000
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
    {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
        self.modalPresentationCapturesStatusBarAppearance = NO;
    }
#endif
    //银行卡号
    UILabel *accountLab = [[UILabel alloc] initWithFrame:CGRectMake(20, 101, 75, 14)];
    accountLab.text = @"绑定银行:";
    accountLab.font = [UIFont boldSystemFontOfSize:14];
    [self.view addSubview:accountLab];
    
    bankNumTF = [[UIButton alloc] initWithFrame:CGRectMake(95, 88, ScreenWidth - 115, 35)];
    bankNumTF.layer.borderWidth = 1;
    bankNumTF.layer.borderColor = [[UIColor blackColor] CGColor];
    bankNumTF.layer.cornerRadius = 5;
    bankNumTF.backgroundColor = [UIColor whiteColor];
    //[bankNumTF setTitle:@"请输入银行" forState:UIControlStateNormal];
    [bankNumTF addTarget:self action:@selector(showMenu:) forControlEvents:UIControlEventTouchUpInside];
    SelectLable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth - 95 - 20, 30)];
    SelectLable.font = [UIFont systemFontOfSize:12];
    SelectLable.textAlignment = NSTextAlignmentLeft;
    SelectLable.textColor = [ColorUtil colorWithHexString:@"7f7f7f"];
    SelectLable.text = @"请选择银行";
    [bankNumTF addSubview:SelectLable];
    
    [self.view addSubview:bankNumTF];
    
    
    
    
 
    //密码
    UILabel *passwordLab = [[UILabel alloc] initWithFrame:CGRectMake(20, 151, 75, 14)];
    passwordLab.text = @"转出金额:";
    passwordLab.font = [UIFont boldSystemFontOfSize:14];
    [self.view addSubview:passwordLab];
    password = [[UITextField alloc] initWithFrame:CGRectMake(95, 138, ScreenWidth - 115, 35)];
    [password setBackgroundColor:[UIColor whiteColor]];
    password.borderStyle = UITextBorderStyleLine;
    //[password setBackground:[[UIImage imageNamed:@"head_bg"] resizableImageWithCapInsets:UIEdgeInsetsMake(5, 5, 5, 5) resizingMode:UIImageResizingModeStretch]];
    password.returnKeyType = UIReturnKeyDone;
    password.delegate = self;
    password.placeholder = @"请填写转出金额";
    //[password setText:self.dataString];
    password.clearButtonMode = UITextFieldViewModeAlways;
    [password setFont:[UIFont systemFontOfSize:13]];
    [password setTextColor:[ColorUtil colorWithHexString:@"383838"]];
    [self.view addSubview:password];
    
    UILabel *tipBankLabel = [[UILabel alloc] initWithFrame:CGRectMake(195, 178 , ScreenWidth - 195 - 20, 10)];
    tipBankLabel.font = [UIFont systemFontOfSize:10];
    tipBankLabel.textColor = [ColorUtil colorWithHexString:@"7f7f7f"];
    tipBankLabel.text = @"单位:(元)";
    tipBankLabel.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:tipBankLabel];
    
    
    
    UIButton *commitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    commitBtn.frame = CGRectMake(50, 234, ScreenWidth - 100, 50);
    [commitBtn setTitle:@"提交" forState:UIControlStateNormal];
    [commitBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    commitBtn.backgroundColor = [UIColor blueColor];
    [commitBtn addTarget:self action:@selector(commitBtnMethods:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:commitBtn];

}

- (void)showMenu:(UIButton *)sender
{
    NSMutableArray *array2 = [[NSMutableArray alloc] init];
    array3 = @[@{@"identfy":@"JSYH",@"name":@"建设银行"}];
    for (int i = 0; i < array3.count; i++) {
        KxMenuItem *kx =
        [KxMenuItem menuItem:[[array3 objectAtIndex:i] objectForKey:@"name"]
                       image:[UIImage imageNamed:@"action_icon"]
                      target:self
                      action:@selector(pushMenuItem:)];
        // kx.target = [NSString stringWithFormat:@"%i",i];
        
        [array2 addObject:kx];
    }
    
    
    [KxMenu showMenuInView:self.view
                  fromRect:CGRectMake(95, 72, 200, 80)
                 menuItems:array2];
    [KxMenu setTintColor:[UIColor whiteColor]];
}

- (void) pushMenuItem:(KxMenuItem *)sender
{
    for (int i = 0;i< array3.count;i++) {
        for (NSString *str in [[array3 objectAtIndex:i] allObjects]) {
            if ([str isEqualToString:sender.title]) {
                bankName = [[array3 objectAtIndex:i] objectForKey:@"identfy"];
            }
        }
    }
    
    
    [SelectLable setText:sender.title];
    
    
    NSLog(@"999999%@", bankName);
}




-(void)commitBtnMethods:(id)sender {
    if ([bankName isEqualToString:@""]) {
        [self.view makeToast:@"请选择银行"];
        
    } else if ([password.text isEqualToString:@""]) {
        [self.view makeToast:@"请输入银行密码"];
        
    } else {
        [self requestCategoryList:bankName yhzh:password.text tag:kBusinessTagGetBankCJAgain];
        //添加指示器及遮罩
        HUD = [[MBProgressHUD alloc] initWithView:self.view];
        HUD.dimBackground = YES;
        HUD.delegate = self;
        HUD.labelText = @"登录中";
        [HUD show:YES];
        [self.view addSubview:HUD];
    }
 
    
    
}


#pragma mark - Request Methods
//获取品牌列表
- (void)requestCategoryList:(NSString *)yhdm yhzh:(NSString *)yhzh   tag:(kBusinessTag)_tag
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"请求品牌列表");
    NSMutableDictionary *paraDic = [[NSMutableDictionary alloc] init];
    [paraDic setObject:yhdm forKey:@"yhdm"];
    [paraDic setObject:yhzh forKey:@"zzje"];
    [[NetworkModule sharedNetworkModule] postBusinessReqWithParamters:paraDic tag:_tag owner:self];
    
}

#pragma mark - Recived Methods
//处理品牌列表
- (void)recivedCategoryList:(NSMutableArray *)dataArray
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"处理品牌列表数据");
    
}
#pragma mark - NetworkModuleDelegate Methods
-(void)beginPost:(kBusinessTag)tag{
    
}
-(void)endPost:(NSString *)result business:(kBusinessTag)tag{
    NSLog(@"%s %d 收到数据:%@", __FUNCTION__, __LINE__, result);
    NSMutableDictionary *jsonDic = [result JSONValue];
    
	if (tag==kBusinessTagGetBankCJAgain ) {
        [HUD hide:YES];
        if ([[jsonDic objectForKey:@"success"] boolValue] == 0) {
            //数据异常处理
            [self.view makeToast:[jsonDic objectForKey:@"msg"]];
        } else {
            [self.view makeToast:[jsonDic objectForKey:@"msg"]];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    [[NetworkModule sharedNetworkModule] cancel:tag];
}
-(void)errorPost:(NSError *)err business:(kBusinessTag)tag{
    NSLog(@"%s Error:%@", __FUNCTION__, @"连接数据服务器超时");
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法连接" message:@"您所在地的网络信号微弱，无法连接到服务" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    if (tag == kBusinessTagGetBankCJAgain) {
        [HUD hide:YES];
    }
    [[NetworkModule sharedNetworkModule] cancel:tag];
}





-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    [self.view endEditing:YES];
    
}



-(void)push {
    [self.navigationController popViewControllerAnimated:YES];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    [bankNumTF removeFromSuperview];
    bankNumTF = nil;
    [password removeFromSuperview];
    password = nil;
    [HUD removeFromSuperview];
    HUD = nil;
    [SelectLable removeFromSuperview];
    SelectLable = nil;
     array3 = nil;
     bankName = nil;
 
}


@end
