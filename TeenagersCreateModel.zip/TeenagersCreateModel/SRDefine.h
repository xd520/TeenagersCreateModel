//
//  SRDefine.h
//  SlimeRefresh
//
//  Created by zrz on 12-6-15.
//  Copyright (c) 2012年 zrz. All rights reserved.
//

#ifndef SlimeRefresh_SRDefine_h
#define SlimeRefresh_SRDefine_h

#define kStartTo    0.7f
#define kEndTo      0.15f

#define kRefreshImageWidth  17.0f
#define kAnimationInterval  (1.0f/50.0f)

#endif
