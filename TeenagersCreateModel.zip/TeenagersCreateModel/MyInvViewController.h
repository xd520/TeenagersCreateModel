//
//  MyInvViewController.h
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-5.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface MyInvViewController : UIViewController <NetworkModuleDelegate,MBProgressHUDDelegate,UITableViewDataSource,UITableViewDelegate>

@end
