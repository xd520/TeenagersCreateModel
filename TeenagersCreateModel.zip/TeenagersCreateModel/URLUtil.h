//
//  URLUtil.h
//  WeiXiu
//
//  Created by Chris on 13-7-15.
//  Copyright (c) 2013年 Chris. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetworkModule.h"
@interface URLUtil : NSObject
+ (NSString *)getURLByBusinessTag:(kBusinessTag)tag;
@end
