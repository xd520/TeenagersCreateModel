//
//  CusTableview.m
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-26.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import "CusTableview.h"


@implementation CusTableview

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)dealloc{
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
