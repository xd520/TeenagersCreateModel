//
//  RegisterViewController.m
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-12.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import "RegisterViewController.h"
#import "AppDelegate.h"
#import "QCheckBox.h"

@interface RegisterViewController ()
{
    UIScrollView *scrollView;
    
    UITextField *userName;
    UITextField *passWord;
    UITextField *name;
    UITextField *phoneNum;
    UITextField *passNum;
    UITextField *email;
    QCheckBox *_check1;
    QCheckBox *_check2;
    NSString *rateStr1;
    NSString *rateStr2;
    
    UILabel *nameLabel;
    UILabel *passNumLabel;
    UILabel *codeLabel;
    UILabel *personLabel;
    UITextField *cede;
    UITextField *person;
    
    UIButton *comfirmBtn;
    UIButton *personBtn;
    MBProgressHUD *HUD;
    
}
@end

@implementation RegisterViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


-(void)loadView {
    [super loadView];
    UIView *baseView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
    baseView.backgroundColor = [ColorUtil colorWithHexString:@"f5f4f2"];
    //baseView.backgroundColor = [UIColor grayColor];
    self.view = baseView;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    rateStr1 = @"";
    rateStr2 = @"";
    
    UINavigationBar *navibar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, ScreenWidth, 44)];
    navibar.userInteractionEnabled = YES;
    //navibar.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"navbar.png"]];
    [navibar setBackgroundImage:[UIImage imageNamed:@"background.jpg"]  forBarMetrics:UIBarMetricsDefault];
    
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 21, 21);
    [leftBtn setImage:[UIImage imageNamed:@"head_icon_back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(push:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    UINavigationItem *navibarItem = [[UINavigationItem alloc]init];
    navibarItem.title = @"注册创建人";
    navibarItem.leftBarButtonItem= leftItem;
    // self.navigationItem.rightBarButtonItem = leftItem;
    [navibar pushNavigationItem:navibarItem animated:YES];
    [self.view addSubview:navibar];
    
    //加入滑动视图
    
    scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64, ScreenWidth, ScreenHeight - 64)];
    //scrollView.backgroundColor = [UIColor grayColor];
    [scrollView setContentSize:CGSizeMake(ScreenWidth, 600)];
    
    _check1 = [[QCheckBox alloc] initWithDelegate:self];
    _check1.frame = CGRectMake(115, 22,100,22);
    [_check1 setTitle:@"创业项目" forState:UIControlStateNormal];
    [_check1 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    _check1.tag = 1;
    [_check1.titleLabel setFont:[UIFont boldSystemFontOfSize:13.0f]];
    [_check1 setChecked:YES];
    [scrollView addSubview:_check1];
    
    _check2 = [[QCheckBox alloc] initWithDelegate:self];
    _check2.frame = CGRectMake(210,22,100,22);
    [_check2 setTitle:@"创业企业" forState:UIControlStateNormal];
    _check2.tag = 2;
    [_check2 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [_check2.titleLabel setFont:[UIFont boldSystemFontOfSize:13.0f]];
    
    
    [scrollView addSubview:_check2];
    
    
    [self.view addSubview:scrollView];

    [self reloadDataView];
    
}

#pragma mark - QCheckBoxDelegate

- (void)didSelectedCheckBox:(QCheckBox *)checkbox checked:(BOOL)checked {
    
    //只能单选或不选
    if (_check2.checked == YES && _check1.checked == YES) {
        if (_check1 ==checkbox) {
            [_check2 setChecked:NO];
        } else {
            [_check1 setChecked:NO];
            
        }
    }
    
    
    if (checked == 1) {
        if (checkbox.tag == 1) {
            rateStr1 = @"0";
            [nameLabel setText:@"姓名:"];
            [passNumLabel setText:@"身份证号码:"];
            cede.hidden = YES;
            person.hidden = YES;
            codeLabel.hidden = YES;
            personLabel.hidden = YES;
            comfirmBtn.hidden = YES;
            personBtn.hidden = NO;
        } else if (checkbox.tag == 2) {
          
            rateStr2 = @"1";
           [nameLabel setText:@"法机构名称:"];
            [passNumLabel setText:@"证件号码:"];
            cede.hidden = NO;
             person.hidden = NO;
            codeLabel.hidden = NO;
            personLabel.hidden = NO;
            comfirmBtn.hidden = NO;
            personBtn.hidden = YES;
        }
    }
    
    
     NSLog(@"%@--676767--%@",rateStr1,rateStr2);
}




-(void)reloadDataView {
    
    NSArray *arr = @[@"类  别:",@"用户名:",@"密  码:",@"手  机:",@"邮  箱:"];
    for (int i = 0; i < arr.count ; i++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 17.5 + 40*i, 100, 30)];
        label.textAlignment = NSTextAlignmentRight;
        label.font = [UIFont systemFontOfSize:15];
        label.text = [arr objectAtIndex:i];
        [scrollView addSubview:label];
        
    }
    
    nameLabel= [[UILabel alloc] initWithFrame:CGRectMake(20, 17.5 + 40*5, 90, 30)];
    nameLabel.textAlignment = NSTextAlignmentRight;
    nameLabel.font = [UIFont systemFontOfSize:15];
    nameLabel.text = @"姓   名:";
    [scrollView addSubview:nameLabel];
    
    passNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 17.5 + 40*6, 90, 30)];
    passNumLabel.textAlignment = NSTextAlignmentRight;
    passNumLabel.font = [UIFont systemFontOfSize:15];
    passNumLabel.text = @"身份证号码:";
    [scrollView addSubview:passNumLabel];
    
    codeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 17.5 + 40*7, 100, 30)];
    codeLabel.textAlignment = NSTextAlignmentRight;
    codeLabel.font = [UIFont systemFontOfSize:15];
    codeLabel.text = @"营业执照编码:";
    [scrollView addSubview:codeLabel];
    
    personLabel= [[UILabel alloc] initWithFrame:CGRectMake(20, 17.5 + 40*8, 90, 30)];
    personLabel.textAlignment = NSTextAlignmentRight;
    personLabel.font = [UIFont systemFontOfSize:15];
    personLabel.text = @"法定代表人:";
    [scrollView addSubview:personLabel];
    
    
//用户名
    userName = [[UITextField alloc] initWithFrame:CGRectMake(110, 60, 200, 30)];
    userName.borderStyle = UITextBorderStyleLine;
    userName.clearButtonMode = UITextFieldViewModeAlways;
    userName.delegate = self;
    userName.placeholder = @"请填写用户名";
    //@"字母开头，4~16位字符，可包含英文字母，数字、\"_\""
    userName.font = [UIFont systemFontOfSize:12];
    [scrollView addSubview:userName];
//密码
    passWord= [[UITextField alloc] initWithFrame:CGRectMake(110, 100, 200, 30)];
    passWord.borderStyle = UITextBorderStyleLine;
    passWord.clearButtonMode = UITextFieldViewModeAlways;
    passWord.secureTextEntry = YES;
    passWord.delegate = self;
    passWord.placeholder = @"请输入密码";
    passWord.font = [UIFont systemFontOfSize:12];
    [scrollView addSubview:passWord];
    
//手机
    
    passNum = [[UITextField alloc] initWithFrame:CGRectMake(110, 140, 200, 30)];
    passNum.borderStyle = UITextBorderStyleLine;
    passNum.clearButtonMode = UITextFieldViewModeAlways;
    passNum.tag = 2;
    passNum.delegate = self;
    passNum.placeholder = @"请填写有效掌控的手机号码";
    passNum.font = [UIFont systemFontOfSize:12];
    [scrollView addSubview:passNum];
//邮箱
    email = [[UITextField alloc] initWithFrame:CGRectMake(110, 180, 200, 30)];
    email.borderStyle = UITextBorderStyleLine;
    email.clearButtonMode = UITextFieldViewModeAlways;
    email.delegate = self;
    email.placeholder = @"请输入常用的邮箱";
    email.font = [UIFont systemFontOfSize:12];
    [scrollView addSubview:email];
// 姓名
    name= [[UITextField alloc] initWithFrame:CGRectMake(110, 220, 200, 30)];
    name.borderStyle = UITextBorderStyleLine;
    name.clearButtonMode = UITextFieldViewModeAlways;
    name.delegate = self;
    name.placeholder = @"请输入姓名";
    name.font = [UIFont systemFontOfSize:12];
    [scrollView addSubview:name];
//身份证号码
    phoneNum= [[UITextField alloc] initWithFrame:CGRectMake(110, 260, 200, 30)];
    phoneNum.borderStyle = UITextBorderStyleLine;
    phoneNum.clearButtonMode = UITextFieldViewModeAlways;
    phoneNum.delegate = self;
    phoneNum.tag = 1;
    phoneNum.placeholder = @"请输入身份证号";
    phoneNum.font = [UIFont systemFontOfSize:12];
    [scrollView addSubview:phoneNum];
//营业执照编码
    
    cede = [[UITextField alloc] initWithFrame:CGRectMake(110, 300, 200, 30)];
    cede.borderStyle = UITextBorderStyleLine;
    cede.clearButtonMode = UITextFieldViewModeAlways;
    cede.delegate = self;
    cede.placeholder = @"请输入营业执照编码";
    cede.font = [UIFont systemFontOfSize:12];
    [scrollView addSubview:cede];
 //法定代表人
    
    person = [[UITextField alloc] initWithFrame:CGRectMake(110, 340, 200, 30)];
    person.borderStyle = UITextBorderStyleLine;
    person.clearButtonMode = UITextFieldViewModeAlways;
    person.delegate = self;
    person.placeholder = @"请输入法定代表人";
    person.font = [UIFont systemFontOfSize:12];
    [scrollView addSubview:person];
    
    cede.hidden = YES;
    person.hidden = YES;
    codeLabel.hidden = YES;
    personLabel.hidden = YES;
    
    
    comfirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    comfirmBtn.frame = CGRectMake(50, 440, 220, 40);
    comfirmBtn.backgroundColor = [UIColor blueColor];
    comfirmBtn.tag = 111112;
    comfirmBtn.hidden = YES;
    [comfirmBtn setTitle:@"注册" forState:UIControlStateNormal];
    [comfirmBtn addTarget:self action:@selector(comfirmBtnMethods:) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:comfirmBtn];
    
    personBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    personBtn.frame = CGRectMake(50, 350, 220, 40);
    personBtn.tag = 111111;
    personBtn.backgroundColor = [UIColor blueColor];
    [personBtn setTitle:@"注册" forState:UIControlStateNormal];
    [personBtn addTarget:self action:@selector(comfirmBtnMethods:) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:personBtn];
    
    
    
    
     [scrollView setContentSize:CGSizeMake(ScreenWidth, 600)];
}


-(void)comfirmBtnMethods:(UIButton *)btn {
    if (btn.tag == 111111) {
        if ([userName.text isEqualToString:@""]) {
            [self.view makeToast:@"请输入用户名"];
        } else if ([passWord.text isEqualToString:@""]){
        [self.view makeToast:@"请输入密码"];
        } else if ([phoneNum.text isEqualToString:@""]){
            [self.view makeToast:@"请输入手机号码"];
        } else if ([email.text isEqualToString:@""]){
            [self.view makeToast:@"请输入邮箱"];
        } else if ([name.text isEqualToString:@""]){
            [self.view makeToast:@"请输入姓名"];
        } else if ([passNum.text isEqualToString:@""]){
            [self.view makeToast:@"请输入身份证号码"];
        } else {
        
            [self requestPersonRegister:rateStr1 yhm:userName.text khmc:name.text zjbh:phoneNum.text mobile:passNum.text email:email.text psw:passWord.text tag:kBusinessTagGetRZF];
            //添加指示器及遮罩
            HUD = [[MBProgressHUD alloc] initWithView:self.view];
            HUD.dimBackground = YES;
            HUD.delegate = self;
            HUD.labelText = @"登录中";
            [HUD show:YES];
            [self.view addSubview:HUD];
        
        }
        
        
    } else if (btn.tag == 111112){
    
        if ([userName.text isEqualToString:@""]) {
            [self.view makeToast:@"请输入用户名"];
        } else if ([passWord.text isEqualToString:@""]){
            [self.view makeToast:@"请输入密码"];
        } else if ([phoneNum.text isEqualToString:@""]){
            [self.view makeToast:@"请输入手机号码"];
        } else if ([email.text isEqualToString:@""]){
            [self.view makeToast:@"请输入邮箱"];
        } else if ([name.text isEqualToString:@""]){
          [self.view makeToast:@"请输入法定机构名称"];
        } else if ([passNum.text isEqualToString:@""]){
            [self.view makeToast:@"请输入法定代表人身份证"];
        }else if ([cede.text isEqualToString:@""]){
           [self.view makeToast:@"请输入营业执照编码"];
        }else if ([person.text isEqualToString:@""]){
           [self.view makeToast:@"请输入法定代表人"];
        }
        else {
            
            [self requestConfirmRegister:rateStr2 yhm:userName.text khmc:name.text zjbh:phoneNum.text mobile:passNum.text email:email.text psw:passWord.text frdb:person.text frdb_zjbh:cede.text tag:kBusinessTagGetRZF];
            //添加指示器及遮罩
            HUD = [[MBProgressHUD alloc] initWithView:self.view];
            HUD.dimBackground = YES;
            HUD.delegate = self;
            HUD.labelText = @"登录中";
            [HUD show:YES];
            [self.view addSubview:HUD];
            
        }
        
    
    }
}


//获取品牌列表
- (void)requestPersonRegister:(NSString *)yhdm yhm:(NSString *)yhzh  khmc:(NSString *)yhmm zjbh:(NSString *)zjbh  mobile:(NSString *)mobile email:(NSString *)eml  psw:(NSString *)psw tag:(kBusinessTag)_tag
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"请求品牌列表");
    NSMutableDictionary *paraDic = [[NSMutableDictionary alloc] init];
    [paraDic setObject:yhdm forKey:@"jgbz"];
    [paraDic setObject:yhzh forKey:@"yhm"];
    [paraDic setObject:yhmm forKey:@"khmc"];
    [paraDic setObject:@"0" forKey:@"zjlb"];
    [paraDic setObject:zjbh forKey:@"zjbh"];
    [paraDic setObject:mobile forKey:@"mobile"];
    [paraDic setObject:eml forKey:@"email"];
    [paraDic setObject:psw forKey:@"psw"];
    
    [[NetworkModule sharedNetworkModule] postBusinessReqWithParamters:paraDic tag:_tag owner:self];
    
}

- (void)requestConfirmRegister:(NSString *)yhdm yhm:(NSString *)yhzh  khmc:(NSString *)yhmm zjbh:(NSString *)zjbh  mobile:(NSString *)mobile email:(NSString *)eml  psw:(NSString *)psw frdb:(NSString *)frdb  frdb_zjbh:(NSString *)frdb_zjbh tag:(kBusinessTag)_tag
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"请求品牌列表");
    NSMutableDictionary *paraDic = [[NSMutableDictionary alloc] init];
    [paraDic setObject:yhdm forKey:@"jgbz"];
    [paraDic setObject:yhzh forKey:@"yhm"];
    [paraDic setObject:yhmm forKey:@"khmc"];
    [paraDic setObject:@"0" forKey:@"zjlb"];
    [paraDic setObject:zjbh forKey:@"zjbh"];
    [paraDic setObject:mobile forKey:@"mobile"];
    [paraDic setObject:eml forKey:@"email"];
    [paraDic setObject:psw forKey:@"psw"];
    
    [paraDic setObject:frdb forKey:@"frdb"];
    [paraDic setObject:@"0" forKey:@"zjlb_frdb"];
    [paraDic setObject:frdb_zjbh forKey:@"zjbh_frdb"];
    [[NetworkModule sharedNetworkModule] postBusinessReqWithParamters:paraDic tag:_tag owner:self];
    
}


#pragma mark - Recived Methods
//处理品牌列表
- (void)recivedCategoryList:(NSMutableArray *)dataArray
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"处理品牌列表数据");
    
}
#pragma mark - NetworkModuleDelegate Methods
-(void)beginPost:(kBusinessTag)tag{
    
}
-(void)endPost:(NSString *)result business:(kBusinessTag)tag{
    NSLog(@"%s %d 收到数据:%@", __FUNCTION__, __LINE__, result);
    NSMutableDictionary *jsonDic = [result JSONValue];
    
	if (tag==kBusinessTagGetRZF ) {
        [HUD hide:YES];
        if ([[jsonDic objectForKey:@"success"] boolValue] == 0) {
            //数据异常处理
            [self.view makeToast:[jsonDic objectForKey:@"msg"]];
        } else {
            [self.view makeToast:@"注册成功"];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    [[NetworkModule sharedNetworkModule] cancel:tag];
}
-(void)errorPost:(NSError *)err business:(kBusinessTag)tag{
    NSLog(@"%s Error:%@", __FUNCTION__, @"连接数据服务器超时");
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法连接" message:@"您所在地的网络信号微弱，无法连接到服务" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    if (tag == kBusinessTagGetRZF) {
        [HUD hide:YES];
    }
    [[NetworkModule sharedNetworkModule] cancel:tag];
}



- (void)textFieldDidEndEditing:(UITextField *)textField{
    NSLog(@"%d",textField.tag);
 //手机验证
    if (textField.tag == 2) {
        NSMutableDictionary *paraDic = [[NSMutableDictionary alloc] init];
        [paraDic setObject:passNum.text forKey:@"mobile"];
       
        [[NetworkModule sharedNetworkModule] postBusinessReqWithParamters:paraDic tag:kBusinessTagGetYzmobile owner:self];
        
        
    } else if (textField.tag == 1) {
    
        NSMutableDictionary *paraDic = [[NSMutableDictionary alloc] init];
        [paraDic setObject:phoneNum.text forKey:@"zjbh"];
        [paraDic setObject:@"0" forKey:@"zjlb"];
        [[NetworkModule sharedNetworkModule] postBusinessReqWithParamters:paraDic tag:kBusinessTagGetYzzjbh owner:self];
    
    
    }
    
    
    
//证件验证
    
    


}


- (void)textFieldDidBeginEditing:(UITextField *)textField
{
   // foucsTextField = textField;
    scrollView.contentSize = CGSizeMake(320,600 +216);//原始滑动距离增加键盘高度
    CGPoint pt = [textField convertPoint:CGPointMake(0, 0) toView:scrollView];//把当前的textField的坐标映射到scrollview上
    if(scrollView.contentOffset.y-pt.y+64<=0)//判断最上面不要去滚动
        [scrollView setContentOffset:CGPointMake(0, pt.y-64) animated:YES];//华东
    
    
}


- (BOOL)textFieldShouldReturn:(UITextField*)theTextField
{
    {
        [theTextField resignFirstResponder];
        
        //开始动画
        [UIView beginAnimations:nil context:nil];
        //设定动画持续时间
        [UIView setAnimationDuration:0.3];
        scrollView.frame = CGRectMake(0, 64, ScreenWidth, ScreenHeight - 64);
        scrollView.contentSize = CGSizeMake(ScreenWidth,600);
        //动画结束
        [UIView commitAnimations];
        
        
    }
    return YES;
}


-(void)push:(UIButton *)btn {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    //[self.view endEditing:YES];
    [userName resignFirstResponder];
    [name resignFirstResponder];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   [[NSURLCache sharedURLCache] removeAllCachedResponses];
}

-(void)dealloc {
    [userName removeFromSuperview];
    userName =nil;
    [passWord removeFromSuperview];
    passWord =nil;
    [name removeFromSuperview];
    name =nil;
    [phoneNum removeFromSuperview];
    phoneNum =nil;
    [passNum removeFromSuperview];
    passNum =nil;
    [email removeFromSuperview];
    email =nil;
    [_check1 removeFromSuperview];
    _check1 =nil;
    [_check2 removeFromSuperview];
    _check2 =nil;
    rateStr1 = nil;
    rateStr2 = nil;
    [nameLabel removeFromSuperview];
    nameLabel =nil;
    [passNumLabel removeFromSuperview];
    passNumLabel =nil;
    [codeLabel removeFromSuperview];
    codeLabel =nil;
    [personLabel removeFromSuperview];
    personLabel =nil;
    [cede removeFromSuperview];
    cede =nil;
    [person removeFromSuperview];
    person =nil;
    
    [comfirmBtn removeFromSuperview];
    comfirmBtn =nil;
    [personBtn removeFromSuperview];
    personBtn =nil;
    [HUD removeFromSuperview];
    HUD =nil;
   

}


@end
