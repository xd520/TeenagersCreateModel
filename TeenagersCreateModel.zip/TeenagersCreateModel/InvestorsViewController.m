//
//  InvestorsViewController.m
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-12.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import "InvestorsViewController.h"
#import "AppDelegate.h"
#import "QCheckBox.h"


@interface InvestorsViewController ()
{
    
    NSMutableArray *array1;
    
    UITextField *zcText;
    UITextField *nsrText;
    UITextField *gsText;
    UITextField *zwText;
    MBProgressHUD *HUD;
    UIImagePickerController *imagePicker;
    int number;
}
@end

@implementation InvestorsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)loadView {
    [super loadView];
    UIView *baseView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
    baseView.backgroundColor = [ColorUtil colorWithHexString:@"f5f4f2"];
    //baseView.backgroundColor = [UIColor grayColor];
    self.view = baseView;
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reloadImageView];

}

- (void)viewDidLoad
{
    [super viewDidLoad];
    array1 = [[NSMutableArray alloc] init];
    number = 0;
    UINavigationBar *navibar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, ScreenWidth, 44)];
    navibar.userInteractionEnabled = YES;
    //navibar.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"navbar.png"]];
    [navibar setBackgroundImage:[UIImage imageNamed:@"title_bg"]  forBarMetrics:UIBarMetricsDefault];
    
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 21, 21);
    [leftBtn setImage:[UIImage imageNamed:@"return_ico"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(push:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    UINavigationItem *navibarItem = [[UINavigationItem alloc]init];
    navibarItem.title = @"个人升级投资人申请";
    navibarItem.leftBarButtonItem= leftItem;
    // self.navigationItem.rightBarButtonItem = leftItem;
    [navibar pushNavigationItem:navibarItem animated:YES];
    [self.view addSubview:navibar];
    
    NSArray *arr = @[@"资   产:",@"年收入:",@"公   司:",@"职   位:",@"身份证附件:",@"资产证明文件:",@"明   片:"];
    for (int i = 0; i < arr.count ; i++) {
        if ( i== 5) {
            
       
            UILabel *baseLabel = [[UILabel alloc] initWithFrame:CGRectMake(10,84 + 40*i  + 40, 80, 40)];
            baseLabel.numberOfLines = 0;
        baseLabel.textAlignment = NSTextAlignmentRight;
            baseLabel.font = [UIFont boldSystemFontOfSize:14];
            baseLabel.text = [arr objectAtIndex:i];
            [self.view addSubview:baseLabel];
        } else if (i == 6){
            UILabel *baseLabel = [[UILabel alloc] initWithFrame:CGRectMake(10,84 + 40*i  + 80, 80, 40)];
            baseLabel.numberOfLines = 0;
            baseLabel.textAlignment = NSTextAlignmentRight;
            baseLabel.font = [UIFont boldSystemFontOfSize:14];
            baseLabel.text = [arr objectAtIndex:i];
            [self.view addSubview:baseLabel];
        
        }
        else {
            UILabel *baseLabel = [[UILabel alloc] initWithFrame:CGRectMake(10,84 + 40*i, 80, 40)];
            baseLabel.numberOfLines = 0;
            baseLabel.textAlignment = NSTextAlignmentRight;
            baseLabel.font = [UIFont boldSystemFontOfSize:14];
            baseLabel.text = [arr objectAtIndex:i];
            [self.view addSubview:baseLabel];
        
        
        
        }
    }
    
//用户名
    zcText = [[UITextField alloc] initWithFrame:CGRectMake(100,90, 200, 30)];
    zcText.borderStyle = UITextBorderStyleLine;
    zcText.clearButtonMode = UITextFieldViewModeAlways;
    zcText.delegate = self;
    zcText.placeholder = @"请输入资产";
    zcText.font = [UIFont systemFontOfSize:12];
    [self.view addSubview:zcText];
    
//年收入
    nsrText = [[UITextField alloc] initWithFrame:CGRectMake(100,130, 200, 30)];
    nsrText.borderStyle = UITextBorderStyleLine;
    nsrText.clearButtonMode = UITextFieldViewModeAlways;
    nsrText.delegate = self;
    nsrText.placeholder = @"请输入资产";
    nsrText.font = [UIFont systemFontOfSize:12];
    [self.view addSubview:nsrText];
    
//公司
    gsText = [[UITextField alloc] initWithFrame:CGRectMake(100,170, 200, 30)];
    gsText.borderStyle = UITextBorderStyleLine;
    gsText.clearButtonMode = UITextFieldViewModeAlways;
    gsText.delegate = self;
    gsText.placeholder = @"请输入资产";
    gsText.font = [UIFont systemFontOfSize:12];
    [self.view addSubview:gsText];
    
//职位
    zwText = [[UITextField alloc] initWithFrame:CGRectMake(100,210, 200, 30)];
    zwText.borderStyle = UITextBorderStyleLine;
    zwText.clearButtonMode = UITextFieldViewModeAlways;
    zwText.delegate = self;
    zwText.placeholder = @"请输入资产";
    zwText.font = [UIFont systemFontOfSize:12];
    [self.view addSubview:zwText];
 
//上传身份证附件按钮
   
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(320 - 70,250 , 50, 30);
    btn.backgroundColor = [UIColor blueColor];
    btn.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn setTitle:@"浏览" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnMthods:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    UILabel *labTip = [[UILabel alloc] initWithFrame:CGRectMake(100, 250, 150, 30)];
    labTip.font = [UIFont systemFontOfSize:10];
    labTip.text = @"(最多可上传2张，限制10以内)";
    [self.view addSubview:labTip];
    
    
    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn2.frame = CGRectMake(320 - 70,330 , 50, 30);
    btn2.backgroundColor = [UIColor blueColor];
    btn2.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn2 setTitle:@"浏览" forState:UIControlStateNormal];
    [btn2 addTarget:self action:@selector(btnMthods:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
    
    labTip = [[UILabel alloc] initWithFrame:CGRectMake(100, 330, 150, 30)];
    labTip.font = [UIFont systemFontOfSize:10];
    labTip.text = @"(最多可上传1张，限制10以内)";
    [self.view addSubview:labTip];
    
    
   
    
    UIButton *btn3 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn3.frame = CGRectMake(320 - 70,410 , 50, 30);
    btn3.backgroundColor = [UIColor blueColor];
    btn3.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn3 setTitle:@"浏览" forState:UIControlStateNormal];
    [btn3 addTarget:self action:@selector(btnMthods:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn3];
    
    labTip = [[UILabel alloc] initWithFrame:CGRectMake(100, 410, 150, 30)];
    labTip.font = [UIFont systemFontOfSize:10];
    labTip.text = @"(最多可上传1张，限制10以内)";
    [self.view addSubview:labTip];
    
}

-(void)reloadImageView {
    if (array1.count > 0) {
        for (int i = 0; i < array1.count; i++) {
            
    UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(20 + 160*i, 290, 80, 30)];
            lab.textAlignment = NSTextAlignmentRight;
    lab.font = [UIFont systemFontOfSize:14];
    lab.text = [array1 objectAtIndex:i];
    [self.view addSubview:lab];
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.frame = CGRectMake(100 + 160*i, 290, 50, 30);
            [btn setTitle:@"删除" forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            btn.tag = i;
            [btn addTarget:self action:@selector(cancerlBtnMethods:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btn];
            
        }
    }
//    } else {
//    
//        UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(20, 290, 150, 30)];
//        lab.font = [UIFont systemFontOfSize:10];
//        lab.text = @"上传成功图片放置区";
//        [self.view addSubview:lab];
//    
//    }

}

-(void)cancerlBtnMethods:(UIButton *)btn {
    
    [array1 removeObjectAtIndex:btn.tag];

    
}


-(void)btnMthods:(UIButton *)btn {

    
        UIActionSheet *sheet;
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            sheet  = [[UIActionSheet alloc] initWithTitle:@"选择" delegate:self cancelButtonTitle:nil destructiveButtonTitle:@"取消" otherButtonTitles:@"拍照",@"从相册选择", nil];
            
        } else {
            sheet = [[UIActionSheet alloc] initWithTitle:@"选择" delegate:self cancelButtonTitle:nil destructiveButtonTitle:@"取消" otherButtonTitles:@"从相册选择", nil];
        }
        sheet.tag = 255;
        [sheet showInView:self.view];
        

}


#pragma caramer Methods

-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (actionSheet.tag == 255) {
        NSUInteger sourceType = 0;
        // 判断是否支持相机
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            switch (buttonIndex) {
                case 0:
                    // 取消
                    return;
                case 1:{
                    // 相机
                    sourceType = UIImagePickerControllerSourceTypeCamera;
                    //hasLoadedCamera = YES;
                }
                    break;
                case 2:{
                    // 相册
                    sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                    // hasLoadedCamera = YES;
                }
                    break;
            }
        }else {
            if (buttonIndex == 0) {
                return;
            } else {
                sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
            }
        }
        
        [self showcamera:sourceType];
        
    }
}

- (void)showcamera:(NSInteger)tag {
    imagePicker = [[UIImagePickerController alloc] init];
    [imagePicker setDelegate:self];
    //[imagePicker setSourceType:UIImagePickerControllerSourceTypeCamera];
    [imagePicker setAllowsEditing:YES];
    imagePicker.sourceType = tag;
    [self presentViewController:imagePicker animated:YES completion:^{}];
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    // NSLog(@"u a is sb");
    [picker dismissViewControllerAnimated:YES completion:^{}];
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    /* 此处info 有六个值
     * UIImagePickerControllerMediaType; // an NSString UTTypeImage)
     * UIImagePickerControllerOriginalImage;  // a UIImage 原始图片
     * UIImagePickerControllerEditedImage;    // a UIImage 裁剪后图片
     * UIImagePickerControllerCropRect;       // an NSValue (CGRect)
     * UIImagePickerControllerMediaURL;       // an NSURL
     * UIImagePickerControllerReferenceURL    // an NSURL that references an asset in the AssetsLibrary framework
     * UIImagePickerControllerMediaMetadata    // an NSDictionary containing metadata from a captured photo
     */
    
    
    //添加指示器及遮罩
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.dimBackground = YES;
    HUD.delegate = self;
    HUD.labelText = @"登录中";
    [HUD show:YES];
    [self.view addSubview:HUD];
    
    NSData *imageData = UIImageJPEGRepresentation(image, 0.5);

    //NSMutableDictionary *paraDic = [[NSMutableDictionary alloc] init];
    
    [[NetworkModule sharedNetworkModule]postBusinessReqWithParamtersAndFile:nil number:number fileData:imageData tag:kBusinessTagGetRegisterUpfile owner:self];

    
  
    
    
}

#pragma mark - Request Methods
//获取品牌列表
- (void)requestCategoryList:(NSString *)yhdm yhzh:(NSString *)yhzh   tag:(kBusinessTag)_tag
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"请求品牌列表");
    NSMutableDictionary *paraDic = [[NSMutableDictionary alloc] init];
    [paraDic setObject:yhdm forKey:@"yhdm"];
    [paraDic setObject:yhzh forKey:@"zzje"];
    [[NetworkModule sharedNetworkModule] postBusinessReqWithParamters:paraDic tag:_tag owner:self];
    
}

#pragma mark - Recived Methods
//处理品牌列表
- (void)recivedCategoryList:(NSMutableArray *)dataArray
{
    NSLog(@"%s %d %@", __FUNCTION__, __LINE__, @"处理品牌列表数据");
    
}
#pragma mark - NetworkModuleDelegate Methods
-(void)beginPost:(kBusinessTag)tag{
    
}
-(void)endPost:(NSString *)result business:(kBusinessTag)tag{
    NSLog(@"%s %d 收到数据:%@", __FUNCTION__, __LINE__, result);
    NSMutableDictionary *jsonDic = [result JSONValue];
    
	if (tag==kBusinessTagGetRegisterUpfile ) {
        [HUD hide:YES];
        if ([[jsonDic objectForKey:@"success"] boolValue] == 0) {
            //数据异常处理
            [self.view makeToast:[jsonDic objectForKey:@"msg"]];
        } else {
            number ++;
            [self.view makeToast:[NSString stringWithFormat:@"上传成功%d张",number]];
            [array1 addObject:[jsonDic objectForKey:@"object"]];
        
            [self reloadImageView];
            
            
            //NSString *str = [jsonDic objectForKey:@"object"];
        }
    }
    [[NetworkModule sharedNetworkModule] cancel:tag];
}
-(void)errorPost:(NSError *)err business:(kBusinessTag)tag{
    NSLog(@"%s Error:%@", __FUNCTION__, @"连接数据服务器超时");
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法连接" message:@"您所在地的网络信号微弱，无法连接到服务" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    if (tag == kBusinessTagGetRegisterUpfile) {
        [HUD hide:YES];
    }
    [[NetworkModule sharedNetworkModule] cancel:tag];
}





-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


-(void)push:(UIButton *)btn {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
