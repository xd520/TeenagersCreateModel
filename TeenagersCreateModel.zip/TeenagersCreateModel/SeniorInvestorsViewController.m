//
//  SeniorInvestorsViewController.m
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-12.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import "SeniorInvestorsViewController.h"
#import "AppDelegate.h"

@interface SeniorInvestorsViewController ()
{
    UITextField *adreessText;
    UITextField *fundText;
    UITextField *sszbText;
    UITextField *phoneText;
    UITextField *userText;
    

}
@end

@implementation SeniorInvestorsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)loadView {
    [super loadView];
    UIView *baseView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
    baseView.backgroundColor = [ColorUtil colorWithHexString:@"f5f4f2"];
    //baseView.backgroundColor = [UIColor grayColor];
    self.view = baseView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UINavigationBar *navibar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, ScreenWidth, 44)];
    navibar.userInteractionEnabled = YES;
    //navibar.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"navbar.png"]];
    [navibar setBackgroundImage:[UIImage imageNamed:@"background.jpg"]  forBarMetrics:UIBarMetricsDefault];
    
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 21, 21);
    [leftBtn setImage:[UIImage imageNamed:@"head_icon_back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(push:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    UINavigationItem *navibarItem = [[UINavigationItem alloc]init];
    navibarItem.title = @"机构升级投资人申请";
    navibarItem.leftBarButtonItem= leftItem;
    // self.navigationItem.rightBarButtonItem = leftItem;
    [navibar pushNavigationItem:navibarItem animated:YES];
    [self.view addSubview:navibar];
    
    NSArray *arr = @[@"注册地址:",@"注册资本:",@"实收资本:",@"联系人:",@"电话号码",@"组织机构代码附件:",@"营业执照附件:",@"法人代表身份证附件:"];
    for (int i = 0; i < arr.count ; i++) {
        
        UILabel *baseLabel = [[UILabel alloc] initWithFrame:CGRectMake(10,84 + 40*i, 80, 40)];
        baseLabel.numberOfLines = 0;
        baseLabel.textAlignment = NSTextAlignmentRight;
        baseLabel.font = [UIFont boldSystemFontOfSize:14];
        baseLabel.text = [arr objectAtIndex:i];
        [self.view addSubview:baseLabel];
        
    }
    
    //用户名
    
    
    adreessText = [[UITextField alloc] initWithFrame:CGRectMake(100,90, 200, 30)];
    adreessText.borderStyle = UITextBorderStyleLine;
    adreessText.clearButtonMode = UITextFieldViewModeAlways;
    adreessText.delegate = self;
    adreessText.placeholder = @"请输入资产";
    adreessText.font = [UIFont systemFontOfSize:12];
    [self.view addSubview:adreessText];
    
    //年收入
    fundText = [[UITextField alloc] initWithFrame:CGRectMake(100,130, 200, 30)];
    fundText.borderStyle = UITextBorderStyleLine;
    fundText.clearButtonMode = UITextFieldViewModeAlways;
    fundText.delegate = self;
    fundText.placeholder = @"请输入资产";
    fundText.font = [UIFont systemFontOfSize:12];
    [self.view addSubview:fundText];
    
    //公司
    sszbText = [[UITextField alloc] initWithFrame:CGRectMake(100,170, 200, 30)];
    sszbText.borderStyle = UITextBorderStyleLine;
    sszbText.clearButtonMode = UITextFieldViewModeAlways;
    sszbText.delegate = self;
    sszbText.placeholder = @"请输入资产";
    sszbText.font = [UIFont systemFontOfSize:12];
    [self.view addSubview:sszbText];
    
    //职位
    phoneText = [[UITextField alloc] initWithFrame:CGRectMake(100,210, 200, 30)];
    phoneText.borderStyle = UITextBorderStyleLine;
    phoneText.clearButtonMode = UITextFieldViewModeAlways;
    phoneText.delegate = self;
    phoneText.placeholder = @"请输入资产";
    phoneText.font = [UIFont systemFontOfSize:12];
    [self.view addSubview:phoneText];
    
    //职位
    userText = [[UITextField alloc] initWithFrame:CGRectMake(100,250, 200, 30)];
    userText.borderStyle = UITextBorderStyleLine;
    userText.clearButtonMode = UITextFieldViewModeAlways;
    userText.delegate = self;
    userText.placeholder = @"请输入资产";
    userText.font = [UIFont systemFontOfSize:12];
    [self.view addSubview:userText];
    
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


-(void)push:(UIButton *)btn {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
