//
//  LeadingInvestmentViewController.m
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-12.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import "LeadingInvestmentViewController.h"
#import "AppDelegate.h"

@interface LeadingInvestmentViewController ()
{
    UITextView *textView;
    UITextView *textJLView;
    UITextView *textSourceView;
}
@end

@implementation LeadingInvestmentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)loadView {
    [super loadView];
    UIView *baseView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
    baseView.backgroundColor = [ColorUtil colorWithHexString:@"f5f4f2"];
    //baseView.backgroundColor = [UIColor grayColor];
    self.view = baseView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UINavigationBar *navibar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, ScreenWidth, 44)];
    navibar.userInteractionEnabled = YES;
    //navibar.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"navbar.png"]];
    [navibar setBackgroundImage:[UIImage imageNamed:@"title_bg"]  forBarMetrics:UIBarMetricsDefault];
    
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 21, 21);
    [leftBtn setImage:[UIImage imageNamed:@"return_ico"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(push:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    UINavigationItem *navibarItem = [[UINavigationItem alloc]init];
    navibarItem.title = @"申请领头人";
    navibarItem.leftBarButtonItem= leftItem;
    // self.navigationItem.rightBarButtonItem = leftItem;
    [navibar pushNavigationItem:navibarItem animated:YES];
    [self.view addSubview:navibar];
    
    NSArray *arr = @[@"投资理念:",@"投资经历:",@"社会资源:",@"证明文件:"];
    for (int i = 0; i < arr.count; i++) {
        UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(10, 74 + 80*i + 10 *i, 80, 80)];
        lab.text = [arr objectAtIndex:i];
        lab.textAlignment = NSTextAlignmentCenter;
        lab.font = [UIFont boldSystemFontOfSize:14];
        [self.view addSubview:lab];
    }
    
    
    
 //投资理念
    textView = [[UITextView alloc] initWithFrame:CGRectMake(80, 74, 320 - 100, 80)]; //初始化大小并自动释放
    
    textView.textColor = [UIColor blackColor];//设置textview里面的字体颜色
    
    textView.font = [UIFont fontWithName:@"Arial" size:18.0];//设置字体名字和字体大小
    
    textView.delegate = self;//设置它的委托方法
    
    textView.backgroundColor = [UIColor whiteColor];//设置它的背景颜色
    
    
    
    //textView.text = @"Now is the time for all good developers to come to serve their country.\n\nNow is the time for all good developers to come to serve their country.";//设置它显示的内容
    
    textView.returnKeyType = UIReturnKeyDefault;//返回键的类型
    
    textView.keyboardType = UIKeyboardTypeDefault;//键盘类型
    
    textView.scrollEnabled = YES;//是否可以拖动
    
    
    
    //textView.autoresizingMask = UIViewAutoresizingFlexibleHeight;//自适应高度
    
    
    
    [self.view addSubview: textView];
    
 
    
//投资经历
    textJLView= [[UITextView alloc] initWithFrame:CGRectMake(80, 74 + 80 + 10, 320 - 100, 80)]; //初始化大小并自动释放
    
    textJLView.textColor = [UIColor blackColor];//设置textview里面的字体颜色
    
    textJLView.font = [UIFont fontWithName:@"Arial" size:18.0];//设置字体名字和字体大小
    
    textJLView.delegate = self;//设置它的委托方法
    
    textJLView.backgroundColor = [UIColor whiteColor];//设置它的背景颜色
    
    
    
    //textView.text = @"Now is the time for all good developers to come to serve their country.\n\nNow is the time for all good developers to come to serve their country.";//设置它显示的内容
    
    textJLView.returnKeyType = UIReturnKeyDefault;//返回键的类型
    
    textJLView.keyboardType = UIKeyboardTypeDefault;//键盘类型
    
    textJLView.scrollEnabled = YES;//是否可以拖动
    
    
    
    //textJLView.autoresizingMask = UIViewAutoresizingFlexibleHeight;//自适应高度
    
    
    
    [self.view addSubview: textJLView];
    
    
//社会资源
    textSourceView= [[UITextView alloc] initWithFrame:CGRectMake(80, 74 + 180, 320 - 100, 80)]; //初始化大小并自动释放
    
    textSourceView.textColor = [UIColor blackColor];//设置textview里面的字体颜色
    
    textSourceView.font = [UIFont fontWithName:@"Arial" size:14.0];//设置字体名字和字体大小
    
    textSourceView.delegate = self;//设置它的委托方法
    
    textSourceView.backgroundColor = [UIColor whiteColor];//设置它的背景颜色
    
    
    
    //textView.text = @"Now is the time for all good developers to come to serve their country.\n\nNow is the time for all good developers to come to serve their country.";//设置它显示的内容
    
    textSourceView.returnKeyType = UIReturnKeyDefault;//返回键的类型
    
    textSourceView.keyboardType = UIKeyboardTypeDefault;//键盘类型
    
    textSourceView.scrollEnabled = YES;//是否可以拖动
    
    
    
    //textSourceView.autoresizingMask = UIViewAutoresizingFlexibleHeight;//自适应高度
    
    
    
    [self.view addSubview: textSourceView];
    
    
    //证明文件
    
    
    
    
    
    
    
    
    
    
}

-(void)push:(UIButton *)btn {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
