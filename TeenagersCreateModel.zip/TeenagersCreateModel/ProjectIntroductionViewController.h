//
//  ProjectIntroductionViewController.h
//  TeenagersCreateModel
//
//  Created by mac on 14-10-11.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "UIPopoverListView.h"


@interface ProjectIntroductionViewController : UIViewController <UITextFieldDelegate,MBProgressHUDDelegate,NetworkModuleDelegate,SRRefreshDelegate,UITableViewDataSource,UITableViewDelegate,UIPopoverListViewDataSource, UIPopoverListViewDelegate,UISearchBarDelegate>


@end
