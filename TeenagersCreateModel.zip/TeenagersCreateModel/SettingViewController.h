//
//  SettingViewController.h
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-12-11.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController

@end
