//
//  QueryViewController.h
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-7.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface QueryViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,MBProgressHUDDelegate,NetworkModuleDelegate>

@end
