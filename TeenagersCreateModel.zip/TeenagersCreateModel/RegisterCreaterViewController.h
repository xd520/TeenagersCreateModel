//
//  RegisterCreaterViewController.h
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-27.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterCreaterViewController : UIViewController<UITextFieldDelegate>

@end
