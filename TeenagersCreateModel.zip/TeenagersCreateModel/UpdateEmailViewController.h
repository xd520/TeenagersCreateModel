//
//  UpdateEmailViewController.h
//  TeenagersCreateModel
//
//  Created by Yonghui Xiong on 14-11-6.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpdateEmailViewController : UIViewController

@end
